﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D993_BinarySearch
{
    internal class Program
    {
        public static int BinarySearch(int[] arr, int searchItem)
        {
            int start = 0;
            int end = arr.Length-1;
            while(start<=end)
            {
                int mid = (start+end)/2;
                if(searchItem == arr[mid])
                {
                    return mid;
                }
                else if(searchItem < arr[mid])
                {
                    end = mid - 1;
                }
                else
                {
                    start = mid + 1;
                }
            }
            return -1;
        }
        
        static void Main(string[] args)
        {
            
            Console.WriteLine("Please Provide input search item");
            int searchItem = Convert.ToInt32(Console.ReadLine());
            int[] arr = {5,11,20,25,33,49,50,62,67,73 };
            int result = BinarySearch(arr, searchItem);
            if(result < 0)
            {
                Console.WriteLine($"{searchItem} is not found");
            }
            else
            {
                Console.WriteLine($"{searchItem} is found at index: {result}");
            }

            Console.ReadLine();
        }
    }
}
