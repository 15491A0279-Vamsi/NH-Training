﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace D9P2__Linear_Search
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Linear Search
            int[] rollnumbers = { 1, 2, 11, 24, 35, 43, 67, 88, 31, 22, 100 };
            int givenNumber = Convert.ToInt32(Console.ReadLine());
            bool searchFound = false;

            for(int i = 0; i < rollnumbers.Length; i++)
            {
                if(rollnumbers[i] == givenNumber)
                {
                    Console.WriteLine("Search is Successful");
                    Console.WriteLine($"The given number {givenNumber} is in {i} index or {i + 1} position");
                    searchFound = true;
                }
            }
            if (!searchFound)
            {
                Console.WriteLine("Search is Successfull");
            }
            Console.ReadLine();
        }
    }
}
